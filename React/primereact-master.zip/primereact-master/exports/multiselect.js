'use strict';

module.exports = require('./components/multiselect/MultiSelect');