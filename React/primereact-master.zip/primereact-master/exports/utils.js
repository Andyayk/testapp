'use strict';

module.exports = require('./components/utils/PrimeReact');