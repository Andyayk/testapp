import PrimeReact from './components/utils/PrimeReact';
export default PrimeReact;
