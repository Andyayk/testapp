'use strict';

module.exports = require('./components/panel/Panel');