'use strict';

module.exports = require('./components/datatable/DataTable');