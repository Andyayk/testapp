'use strict';

module.exports = require('./components/megamenu/MegaMenu');