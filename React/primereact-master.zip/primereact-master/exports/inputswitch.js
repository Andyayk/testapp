'use strict';

module.exports = require('./components/inputswitch/InputSwitch');