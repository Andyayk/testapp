'use strict';

module.exports = require('./components/splitbutton/SplitButton');