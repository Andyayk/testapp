'use strict';

module.exports = require('./components/messages/Messages');