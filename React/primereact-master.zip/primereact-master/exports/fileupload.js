'use strict';

module.exports = require('./components/fileupload/FileUpload');