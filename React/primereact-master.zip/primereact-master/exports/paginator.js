'use strict';

module.exports = require('./components/paginator/Paginator');