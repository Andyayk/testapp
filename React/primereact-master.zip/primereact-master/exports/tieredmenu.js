'use strict';

module.exports = require('./components/tieredmenu/TieredMenu');