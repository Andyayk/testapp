'use strict';

module.exports = require('./components/organizationchart/OrganizationChart');