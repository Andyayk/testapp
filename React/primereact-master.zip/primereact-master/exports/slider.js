'use strict';

module.exports = require('./components/slider/Slider');