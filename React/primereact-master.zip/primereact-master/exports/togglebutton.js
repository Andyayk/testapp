'use strict';

module.exports = require('./components/togglebutton/ToggleButton');