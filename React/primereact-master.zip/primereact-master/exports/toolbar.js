'use strict';

module.exports = require('./components/toolbar/Toolbar');