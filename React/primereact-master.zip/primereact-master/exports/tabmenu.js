'use strict';

module.exports = require('./components/tabmenu/TabMenu');