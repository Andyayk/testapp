'use strict';

module.exports = require('./components/breadcrumb/BreadCrumb');