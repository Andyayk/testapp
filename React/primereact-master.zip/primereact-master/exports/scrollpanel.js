'use strict';

module.exports = require('./components/scrollpanel/ScrollPanel');