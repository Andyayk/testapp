'use strict';

module.exports = require('./components/contextmenu/ContextMenu');