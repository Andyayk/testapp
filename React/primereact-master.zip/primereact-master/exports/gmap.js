'use strict';

module.exports = require('./components/gmap/GMap');