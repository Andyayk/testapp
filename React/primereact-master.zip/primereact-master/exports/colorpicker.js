'use strict';

module.exports = require('./components/colorpicker/ColorPicker');