'use strict';

module.exports = require('./components/inputtext/InputText');