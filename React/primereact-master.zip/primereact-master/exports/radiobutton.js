'use strict';

module.exports = require('./components/radiobutton/RadioButton');