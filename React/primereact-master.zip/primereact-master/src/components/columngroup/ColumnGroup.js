import { Component } from 'react';

export class ColumnGroup extends Component {
    
}