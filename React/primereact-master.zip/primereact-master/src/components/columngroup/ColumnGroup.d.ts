import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface ColumnGroupProps {
}

export class ColumnGroup extends React.Component<ColumnGroupProps,any> {}
