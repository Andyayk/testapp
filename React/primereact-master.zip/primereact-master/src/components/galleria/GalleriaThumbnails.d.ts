import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface GalleriaThumbnailsProps {
}

export class GalleriaThumbnails extends React.Component<GalleriaThumbnailsProps,any> {}
