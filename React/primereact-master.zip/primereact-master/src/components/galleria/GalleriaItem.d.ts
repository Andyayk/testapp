import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface GalleriaItemProps {
}

export class GalleriaItem extends React.Component<GalleriaItemProps,any> {}
