import * as React from 'react';

// tslint:disable-next-line:no-empty-interface
interface RowTogglerButtonProps {
}

export class RowTogglerButton extends React.Component<RowTogglerButtonProps,any> {}
