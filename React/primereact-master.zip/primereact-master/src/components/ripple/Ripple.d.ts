import * as React from 'react';

interface RippleProps {

}

export class Ripple extends React.Component<RippleProps,any> {}
