import * as React from 'react';

interface RowProps {
    style?: object;
    className?: string;
}

export class Row extends React.Component<RowProps,any> {}