import React from 'react';

const AppContentContext = React.createContext();

export default AppContentContext;
